import React from 'react'

const StatutoryDeclarationA = () => {
  return (
    <div>
      
    </div>
  )
}

export default StatutoryDeclarationA
