import React from 'react'

const StatutoryDeclarationB = () => {
  return (
    <div>
      
    </div>
  )
}

export default StatutoryDeclarationB
