import React from 'react'

export default function Services() {
  return (
    <div className=' h-[440px] grid justify-center items-center'>
      <div className='rounded-md p-4 shadow-md border'>
        Services Coming soon
      </div>
    </div>
  )
}
